version="1.0"
tags={
	"Utilities"
}
name="More Estate Privileges"
supported_version="v1.37.5.0"
